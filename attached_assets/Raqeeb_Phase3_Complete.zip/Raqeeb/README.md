# Raqeeb (رقيب) — Phase 3: Database & Data Persistence

## Quick Start (Visual Studio 2022)

1. Open `Raqeeb.sln`
2. Fill in the three secrets in `Raqeeb.API/appsettings.Development.json`:
   - `Stream:ApiSecret` — your GetStream.io API secret
   - `StreamPay:XApiKey` — your StreamPay X-API-Key (Base64)
   - `N8n:WebhookUrl` — your n8n webhook URL
3. Press **F5** — the SQLite database is created automatically on first run
4. Visit **https://localhost:5001/swagger** for the interactive API docs

## What's implemented (Phase 3)

### Database (SQLite via Entity Framework Core 8)
| Table | Columns |
|---|---|
| Users | Id, Email, PasswordHash, HasActiveSubscription, CreatedAt |
| Contracts | Id, UserId, ContractName, Status, ContractText, StreamChannelId, PaymentLinkId, CreatedAt |
| AuditResults | Id, ContractId, RiskScore, InspectorOutput, LawFinderOutput, DrafterOutput, Severity, ActionTaken, ReviewerNotes, CreatedAt |

### Repository Logic
- **User Check (Gatekeeper)** — `HasActiveSubscriptionAsync()` blocks audit start if not paid
- **Audit Save** — `SaveFromWebhookAsync()` stores n8n JSON directly
- **History Fetch** — `GetByUserIdAsync()` returns all contracts ordered by CreatedAt

### API Endpoints
| Method | Route | Description |
|---|---|---|
| POST | /api/auth/register | Register |
| POST | /api/auth/login | Login (cookie session) |
| GET | /api/auth/me | Current user |
| POST | /api/auth/logout | Logout |
| POST | /api/contracts | Create contract |
| GET | /api/contracts/history | Dashboard history |
| GET | /api/contracts/{id} | Contract detail |
| POST | /api/payments/create-link | StreamPay checkout URL |
| POST | /api/payments/callback | StreamPay webhook |
| GET | /api/payments/verify/{id} | Verify payment |
| POST | /api/audits/start | Start audit (gatekeeper) |
| POST | /api/audits/webhook/n8n | Receive n8n results |
| GET | /api/audits/{contractId} | Get audit result |
| POST | /api/audits/{contractId}/action | Approve/Reject/Review |

### Universal Contract ID
The same `contractId` (GUID) is used in:
- The **database** (primary key in Contracts, foreign key in AuditResults)
- The **n8n webhook** payload (`contractId` field)
- The **Stream Chat** channel ID (`audit-{contractId}`)
