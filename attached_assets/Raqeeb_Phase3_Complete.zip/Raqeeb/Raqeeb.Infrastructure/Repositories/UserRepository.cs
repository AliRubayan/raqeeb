using Microsoft.EntityFrameworkCore;
using Raqeeb.Application.Interfaces;
using Raqeeb.Domain.Entities;
using Raqeeb.Infrastructure.Data;

namespace Raqeeb.Infrastructure.Repositories;

public class UserRepository : IUserRepository
{
    private readonly RaqeebDbContext _db;
    public UserRepository(RaqeebDbContext db) => _db = db;

    public async Task<User?> GetByEmailAsync(string email) =>
        await _db.Users.FirstOrDefaultAsync(u => u.Email == email);

    public async Task<User?> GetByIdAsync(Guid id) =>
        await _db.Users.FindAsync(id);

    /// <summary>
    /// USER CHECK — gatekeeper check before POST /api/audits/start
    /// </summary>
    public async Task<bool> HasActiveSubscriptionAsync(Guid userId)
    {
        var user = await _db.Users.FindAsync(userId);
        return user?.HasActiveSubscription ?? false;
    }

    public async Task<User> CreateAsync(User user)
    {
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
        return user;
    }

    public async Task UpdateSubscriptionAsync(Guid userId, bool hasActiveSubscription)
    {
        var user = await _db.Users.FindAsync(userId);
        if (user is null) return;
        user.HasActiveSubscription = hasActiveSubscription;
        await _db.SaveChangesAsync();
    }
}
