using Microsoft.EntityFrameworkCore;
using Raqeeb.Application.Interfaces;
using Raqeeb.Domain.Entities;
using Raqeeb.Infrastructure.Data;

namespace Raqeeb.Infrastructure.Repositories;

public class ContractRepository : IContractRepository
{
    private readonly RaqeebDbContext _db;
    public ContractRepository(RaqeebDbContext db) => _db = db;

    public async Task<Contract> CreateAsync(Contract contract)
    {
        _db.Contracts.Add(contract);
        await _db.SaveChangesAsync();
        return contract;
    }

    public async Task<Contract?> GetByIdAsync(Guid id) =>
        await _db.Contracts
            .Include(c => c.AuditResult)
            .FirstOrDefaultAsync(c => c.Id == id);

    /// <summary>
    /// HISTORY FETCH — all contracts for a user, newest first.
    /// Powers the Revenue Dashboard analytics (CreatedAt ordering).
    /// </summary>
    public async Task<IEnumerable<Contract>> GetByUserIdAsync(Guid userId) =>
        await _db.Contracts
            .Where(c => c.UserId == userId)
            .Include(c => c.AuditResult)
            .OrderByDescending(c => c.CreatedAt)
            .ToListAsync();

    public async Task UpdateStatusAsync(Guid contractId, ContractStatus status)
    {
        var c = await _db.Contracts.FindAsync(contractId);
        if (c is null) return;
        c.Status = status;
        await _db.SaveChangesAsync();
    }

    public async Task UpdateStreamChannelAsync(Guid contractId, string channelId)
    {
        var c = await _db.Contracts.FindAsync(contractId);
        if (c is null) return;
        c.StreamChannelId = channelId;
        await _db.SaveChangesAsync();
    }

    public async Task UpdatePaymentLinkAsync(Guid contractId, string paymentLinkId)
    {
        var c = await _db.Contracts.FindAsync(contractId);
        if (c is null) return;
        c.PaymentLinkId = paymentLinkId;
        await _db.SaveChangesAsync();
    }
}
