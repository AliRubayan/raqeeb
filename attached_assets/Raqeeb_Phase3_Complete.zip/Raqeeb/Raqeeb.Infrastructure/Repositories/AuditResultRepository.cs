using Microsoft.EntityFrameworkCore;
using Raqeeb.Application.Interfaces;
using Raqeeb.Domain.Entities;
using Raqeeb.Infrastructure.Data;

namespace Raqeeb.Infrastructure.Repositories;

public class AuditResultRepository : IAuditResultRepository
{
    private readonly RaqeebDbContext _db;
    public AuditResultRepository(RaqeebDbContext db) => _db = db;

    /// <summary>
    /// AUDIT SAVE — stores the n8n JSON response directly into AuditResults.
    /// ContractId is the universal key used in DB, n8n, and Stream Chat.
    /// </summary>
    public async Task<AuditResult> SaveFromWebhookAsync(AuditResult result)
    {
        _db.AuditResults.Add(result);
        await _db.SaveChangesAsync();
        return result;
    }

    public async Task<AuditResult?> GetByContractIdAsync(Guid contractId) =>
        await _db.AuditResults.FirstOrDefaultAsync(a => a.ContractId == contractId);

    public async Task UpdateActionAsync(Guid auditResultId, string action, string? notes)
    {
        var r = await _db.AuditResults.FindAsync(auditResultId);
        if (r is null) return;
        r.ActionTaken    = action;
        r.ReviewerNotes  = notes;
        await _db.SaveChangesAsync();
    }
}
