using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Raqeeb.Infrastructure.Services;

/// <summary>
/// Wraps the StreamPay REST API (https://stream-app-service.streampay.sa).
/// Auth: X-API-Key header with Base64-encoded combined key.
/// </summary>
public class StreamPayService
{
    private readonly IHttpClientFactory _factory;
    private readonly IConfiguration _config;
    private readonly ILogger<StreamPayService> _logger;

    private const string BaseUrl       = "https://stream-app-service.streampay.sa";
    private const string AuditProductId = "b226649e-dc8a-4bb9-9b9e-1ddd90d26b58"; // 299 SAR

    public StreamPayService(IHttpClientFactory factory, IConfiguration config, ILogger<StreamPayService> logger)
    {
        _factory = factory;
        _config  = config;
        _logger  = logger;
    }

    private string XApiKey =>
        _config["StreamPay:XApiKey"] ?? throw new InvalidOperationException("StreamPay:XApiKey not configured.");

    private HttpClient CreateClient()
    {
        var http = _factory.CreateClient();
        http.Timeout = TimeSpan.FromSeconds(20);
        http.DefaultRequestHeaders.Add("X-API-Key", XApiKey);
        return http;
    }

    /// <summary>
    /// Creates a StreamPay payment link for a contract audit (299 SAR).
    /// Returns the checkout URL to redirect the user to.
    /// </summary>
    public async Task<string> CreatePaymentLinkAsync(
        Guid contractId,
        string contractName,
        string successUrl,
        string failureUrl)
    {
        var payload = new
        {
            product_id            = AuditProductId,
            reference_id          = contractId.ToString(),
            description           = $"رقيب — تدقيق عقد: {contractName}",
            success_redirect_url  = successUrl,
            failure_redirect_url  = failureUrl,
            currency              = "SAR"
        };

        var request = new HttpRequestMessage(HttpMethod.Post, $"{BaseUrl}/api/v2/payment_links")
        {
            Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json")
        };

        var http     = CreateClient();
        var response = await http.SendAsync(request);
        var body     = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError("StreamPay create-link failed {Status}: {Body}", response.StatusCode, body);
            throw new InvalidOperationException($"StreamPay returned {(int)response.StatusCode}");
        }

        var doc = JsonDocument.Parse(body);
        return doc.RootElement.GetProperty("url").GetString()
               ?? throw new InvalidOperationException("StreamPay response missing 'url'.");
    }

    /// <summary>
    /// Verifies the current status of a payment link.
    /// Returns a status string such as "paid", "pending", or "failed".
    /// </summary>
    public async Task<string> GetPaymentStatusAsync(string paymentLinkId)
    {
        var http     = CreateClient();
        var response = await http.GetAsync($"{BaseUrl}/api/v2/payment_links/{paymentLinkId}");
        var body     = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"StreamPay returned {(int)response.StatusCode}");

        var doc = JsonDocument.Parse(body);
        return doc.RootElement.TryGetProperty("status", out var s)
            ? s.GetString() ?? "unknown"
            : "unknown";
    }
}
