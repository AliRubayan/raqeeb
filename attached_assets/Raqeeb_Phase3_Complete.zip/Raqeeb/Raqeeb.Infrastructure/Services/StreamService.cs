using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Raqeeb.Infrastructure.Services;

/// <summary>
/// Wraps the GetStream.io REST API for the Decision Room (Stream Chat).
/// Uses the Stream API key from configuration.
/// </summary>
public class StreamService
{
    private readonly IHttpClientFactory _factory;
    private readonly IConfiguration _config;
    private readonly ILogger<StreamService> _logger;

    private const string BaseUrl = "https://chat.stream-io-api.com";

    public StreamService(IHttpClientFactory factory, IConfiguration config, ILogger<StreamService> logger)
    {
        _factory = factory;
        _config  = config;
        _logger  = logger;
    }

    private string ApiKey    => _config["Stream:ApiKey"]    ?? throw new InvalidOperationException("Stream:ApiKey not configured.");
    private string ApiSecret => _config["Stream:ApiSecret"] ?? throw new InvalidOperationException("Stream:ApiSecret not configured.");

    /// <summary>
    /// Creates or verifies the Decision Room channel for a contract audit.
    /// Channel type: "messaging", Channel ID: "audit-{contractId}"
    /// </summary>
    public async Task EnsureDecisionRoomAsync(string channelId, string contractName)
    {
        try
        {
            var http = _factory.CreateClient();
            var token = GenerateServerToken();
            http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var payload = new
            {
                data = new
                {
                    name        = $"Decision Room — {contractName}",
                    description = "رقيب: غرفة القرار للعقد المدقق",
                    created_by  = new { id = "system", name = "Raqeeb System" }
                }
            };

            var url     = $"{BaseUrl}/channels/messaging/{channelId}?api_key={ApiKey}";
            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            var response = await http.PostAsync(url, content);

            if (!response.IsSuccessStatusCode)
            {
                var err = await response.Content.ReadAsStringAsync();
                _logger.LogWarning("Stream channel create returned {Status}: {Body}", response.StatusCode, err);
            }
            else
            {
                _logger.LogInformation("Decision Room channel {ChannelId} ready", channelId);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create Stream Chat channel {ChannelId}", channelId);
        }
    }

    /// <summary>
    /// Generates a short-lived server-side JWT for Stream Chat API calls.
    /// </summary>
    private string GenerateServerToken()
    {
        var header  = Base64Url("""{"alg":"HS256","typ":"JWT"}""");
        var payload = Base64Url($$$"""{"iat":{{{DateTimeOffset.UtcNow.ToUnixTimeSeconds()}}},"exp":{{{DateTimeOffset.UtcNow.AddHours(1).ToUnixTimeSeconds()}}}}""");
        var sig     = Base64Url(HmacSha256($"{header}.{payload}", ApiSecret));
        return $"{header}.{payload}.{sig}";
    }

    private static string Base64Url(string input)
    {
        var bytes = Encoding.UTF8.GetBytes(input);
        return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }

    private static string HmacSha256(string data, string key)
    {
        using var hmac = new System.Security.Cryptography.HMACSHA256(Encoding.UTF8.GetBytes(key));
        return Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(data)));
    }
}
