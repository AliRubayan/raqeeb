using Microsoft.EntityFrameworkCore;
using Raqeeb.Domain.Entities;

namespace Raqeeb.Infrastructure.Data;

public class RaqeebDbContext : DbContext
{
    public RaqeebDbContext(DbContextOptions<RaqeebDbContext> options) : base(options) { }

    public DbSet<User>        Users        => Set<User>();
    public DbSet<Contract>    Contracts    => Set<Contract>();
    public DbSet<AuditResult> AuditResults => Set<AuditResult>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<User>(e =>
        {
            e.HasKey(u => u.Id);
            e.HasIndex(u => u.Email).IsUnique();
            e.Property(u => u.Email).IsRequired().HasMaxLength(256);
            e.Property(u => u.PasswordHash).IsRequired();
        });

        mb.Entity<Contract>(e =>
        {
            e.HasKey(c => c.Id);
            e.Property(c => c.ContractName).IsRequired().HasMaxLength(512);
            e.Property(c => c.Status).HasConversion<string>();
            e.HasOne(c => c.User)
             .WithMany(u => u.Contracts)
             .HasForeignKey(c => c.UserId)
             .OnDelete(DeleteBehavior.Cascade);
        });

        mb.Entity<AuditResult>(e =>
        {
            e.HasKey(a => a.Id);
            e.Property(a => a.Severity).HasConversion<string>();
            // One-to-one: Contract <-> AuditResult via ContractId (universal key)
            e.HasOne(a => a.Contract)
             .WithOne(c => c.AuditResult)
             .HasForeignKey<AuditResult>(a => a.ContractId)
             .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
