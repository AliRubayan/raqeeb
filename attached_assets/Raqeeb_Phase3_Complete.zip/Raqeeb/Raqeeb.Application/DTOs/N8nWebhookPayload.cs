namespace Raqeeb.Application.DTOs;

/// <summary>
/// Shape of the JSON that n8n posts to POST /api/audits/webhook/n8n
/// after the three AI agents (Inspector, LawFinder, Drafter) finish.
/// </summary>
public record N8nWebhookPayload(
    Guid ContractId,
    int RiskScore,
    string InspectorOutput,
    string LawFinderOutput,
    string DrafterOutput,
    string Severity   // "Low" | "Medium" | "High"
);
