namespace Raqeeb.Application.DTOs;

public record RegisterRequest(string Email, string Password);
public record LoginRequest(string Email, string Password);
public record CreateContractRequest(string ContractName, string ContractText);
public record AuditStartRequest(Guid ContractId);
public record AuditActionRequest(string Action, string? Notes);
public record CreatePaymentLinkRequest(Guid ContractId);
public record StreamPayCallbackRequest(string SessionId, Guid ContractId, string PaymentStatus);
