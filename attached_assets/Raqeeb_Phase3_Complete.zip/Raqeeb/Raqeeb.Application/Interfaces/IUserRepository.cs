using Raqeeb.Domain.Entities;

namespace Raqeeb.Application.Interfaces;

public interface IUserRepository
{
    Task<User?> GetByEmailAsync(string email);
    Task<User?> GetByIdAsync(Guid id);
    Task<bool> HasActiveSubscriptionAsync(Guid userId);
    Task<User> CreateAsync(User user);
    Task UpdateSubscriptionAsync(Guid userId, bool hasActiveSubscription);
}
