using Raqeeb.Domain.Entities;

namespace Raqeeb.Application.Interfaces;

public interface IContractRepository
{
    Task<Contract> CreateAsync(Contract contract);
    Task<Contract?> GetByIdAsync(Guid id);
    Task<IEnumerable<Contract>> GetByUserIdAsync(Guid userId);
    Task UpdateStatusAsync(Guid contractId, ContractStatus status);
    Task UpdateStreamChannelAsync(Guid contractId, string channelId);
    Task UpdatePaymentLinkAsync(Guid contractId, string paymentLinkId);
}
