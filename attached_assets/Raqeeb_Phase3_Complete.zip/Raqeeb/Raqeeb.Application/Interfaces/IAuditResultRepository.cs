using Raqeeb.Domain.Entities;

namespace Raqeeb.Application.Interfaces;

public interface IAuditResultRepository
{
    Task<AuditResult> SaveFromWebhookAsync(AuditResult result);
    Task<AuditResult?> GetByContractIdAsync(Guid contractId);
    Task UpdateActionAsync(Guid auditResultId, string action, string? notes);
}
