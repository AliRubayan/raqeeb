using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Raqeeb.Application.DTOs;
using Raqeeb.Application.Interfaces;
using Raqeeb.Domain.Entities;

namespace Raqeeb.Application.Services;

public class AuditService
{
    private readonly IUserRepository _users;
    private readonly IContractRepository _contracts;
    private readonly IAuditResultRepository _audits;
    private readonly IHttpClientFactory _httpFactory;
    private readonly IConfiguration _config;
    private readonly ILogger<AuditService> _logger;

    public AuditService(
        IUserRepository users,
        IContractRepository contracts,
        IAuditResultRepository audits,
        IHttpClientFactory httpFactory,
        IConfiguration config,
        ILogger<AuditService> logger)
    {
        _users = users;
        _contracts = contracts;
        _audits = audits;
        _httpFactory = httpFactory;
        _config = config;
        _logger = logger;
    }

    /// <summary>
    /// GATEKEEPER — verifies payment before allowing audit to start.
    /// Returns (true, streamChannelId) on success.
    /// </summary>
    public async Task<(bool Success, string Message)> StartAuditAsync(Guid userId, Guid contractId)
    {
        // 1. Payment check
        var hasPaid = await _users.HasActiveSubscriptionAsync(userId);
        if (!hasPaid)
            return (false, "Payment required before starting audit.");

        // 2. Contract ownership check
        var contract = await _contracts.GetByIdAsync(contractId);
        if (contract == null || contract.UserId != userId)
            return (false, "Contract not found.");

        if (contract.Status != ContractStatus.Paid)
            return (false, $"Contract status is '{contract.Status}' — expected Paid.");

        // 3. Create Stream Chat channel for the Decision Room
        // ContractId is the universal key shared with n8n and Stream Chat
        var channelId = $"audit-{contractId}";
        await _contracts.UpdateStreamChannelAsync(contractId, channelId);
        await _contracts.UpdateStatusAsync(contractId, ContractStatus.Analyzing);

        // 4. Fire n8n webhook so the three AI agents begin
        var n8nUrl = _config["N8n:WebhookUrl"];
        if (!string.IsNullOrWhiteSpace(n8nUrl))
        {
            var payload = new
            {
                contractId = contractId.ToString(),
                contractText = contract.ContractText,
                streamChannelId = channelId
            };
            var json = JsonSerializer.Serialize(payload);
            var http = _httpFactory.CreateClient();
            http.Timeout = TimeSpan.FromSeconds(20);
            try
            {
                await http.PostAsync(n8nUrl, new StringContent(json, Encoding.UTF8, "application/json"));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to call n8n for contract {ContractId}", contractId);
            }
        }

        return (true, channelId);
    }

    /// <summary>
    /// AUDIT SAVE — stores the n8n webhook response into AuditResults.
    /// </summary>
    public async Task<AuditResult> SaveWebhookResultAsync(N8nWebhookPayload payload)
    {
        var severity = Enum.TryParse<Severity>(payload.Severity, true, out var s) ? s : Severity.Medium;

        var result = new AuditResult
        {
            ContractId = payload.ContractId,
            RiskScore  = payload.RiskScore,
            InspectorOutput = payload.InspectorOutput,
            LawFinderOutput = payload.LawFinderOutput,
            DrafterOutput   = payload.DrafterOutput,
            Severity        = severity
        };

        var saved = await _audits.SaveFromWebhookAsync(result);
        await _contracts.UpdateStatusAsync(payload.ContractId, ContractStatus.Completed);
        return saved;
    }

    /// <summary>
    /// HISTORY FETCH — all past contracts for a user (powers the Dashboard).
    /// </summary>
    public async Task<IEnumerable<Contract>> GetUserHistoryAsync(Guid userId)
        => await _contracts.GetByUserIdAsync(userId);
}
