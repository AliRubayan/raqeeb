namespace Raqeeb.Domain.Entities;

public class AuditResult
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ContractId { get; set; }
    public int RiskScore { get; set; }
    public string InspectorOutput { get; set; } = string.Empty;
    public string LawFinderOutput { get; set; } = string.Empty;
    public string DrafterOutput { get; set; } = string.Empty;
    public Severity Severity { get; set; }
    public string? ActionTaken { get; set; }
    public string? ReviewerNotes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Contract Contract { get; set; } = null!;
}
