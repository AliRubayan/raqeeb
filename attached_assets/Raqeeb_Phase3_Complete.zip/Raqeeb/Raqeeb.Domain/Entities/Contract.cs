namespace Raqeeb.Domain.Entities;

public class Contract
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }
    public string ContractName { get; set; } = string.Empty;
    public ContractStatus Status { get; set; } = ContractStatus.Paid;
    public string ContractText { get; set; } = string.Empty;
    public string? StreamChannelId { get; set; }
    public string? PaymentLinkId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public User User { get; set; } = null!;
    public AuditResult? AuditResult { get; set; }
}
