namespace Raqeeb.Domain.Entities;

public enum ContractStatus
{
    Paid,
    Analyzing,
    Completed,
    Rejected
}

public enum Severity
{
    Low,
    Medium,
    High
}
