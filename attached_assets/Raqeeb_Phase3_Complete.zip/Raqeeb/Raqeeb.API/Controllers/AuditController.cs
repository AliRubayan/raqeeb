using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Raqeeb.Application.DTOs;
using Raqeeb.Application.Interfaces;
using Raqeeb.Application.Services;

namespace Raqeeb.API.Controllers;

[ApiController]
[Route("api/audits")]
public class AuditController : ControllerBase
{
    private readonly AuditService            _auditService;
    private readonly IAuditResultRepository  _auditResults;

    public AuditController(AuditService auditService, IAuditResultRepository auditResults)
    {
        _auditService = auditService;
        _auditResults = auditResults;
    }

    private Guid UserId =>
        Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>
    /// POST /api/audits/start
    /// GATEKEEPER — blocks if user has not paid, then fires n8n + creates Decision Room channel.
    /// </summary>
    [HttpPost("start")]
    [Authorize]
    public async Task<IActionResult> Start([FromBody] AuditStartRequest req)
    {
        var (success, message) = await _auditService.StartAuditAsync(UserId, req.ContractId);
        if (!success) return BadRequest(new { error = message });
        return Ok(new { message = "Audit started. AI agents are now analyzing.", streamChannelId = message });
    }

    /// <summary>
    /// POST /api/audits/webhook/n8n
    /// Called by n8n after Inspector, LawFinder, and Drafter agents finish.
    /// Saves results to AuditResults table; contract status → Completed.
    /// </summary>
    [HttpPost("webhook/n8n")]
    [AllowAnonymous]
    public async Task<IActionResult> N8nWebhook([FromBody] N8nWebhookPayload payload)
    {
        var result = await _auditService.SaveWebhookResultAsync(payload);
        return Ok(new { saved = true, auditResultId = result.Id, contractId = payload.ContractId });
    }

    /// <summary>
    /// GET /api/audits/{contractId}
    /// Returns full audit result for the Decision Room UI.
    /// </summary>
    [HttpGet("{contractId:guid}")]
    [Authorize]
    public async Task<IActionResult> GetResult(Guid contractId)
    {
        var result = await _auditResults.GetByContractIdAsync(contractId);
        if (result is null) return NotFound();
        return Ok(result);
    }

    /// <summary>
    /// POST /api/audits/{contractId}/action
    /// Decision Room: Approve / Reject / Review
    /// </summary>
    [HttpPost("{contractId:guid}/action")]
    [Authorize]
    public async Task<IActionResult> TakeAction(Guid contractId, [FromBody] AuditActionRequest req)
    {
        if (req.Action is not ("Approve" or "Reject" or "Review"))
            return BadRequest(new { error = "Action must be: Approve, Reject, or Review" });

        var result = await _auditResults.GetByContractIdAsync(contractId);
        if (result is null) return NotFound(new { error = "Audit result not found." });

        await _auditResults.UpdateActionAsync(result.Id, req.Action, req.Notes);
        return Ok(new { action = req.Action, contractId, updatedAt = DateTime.UtcNow });
    }
}
