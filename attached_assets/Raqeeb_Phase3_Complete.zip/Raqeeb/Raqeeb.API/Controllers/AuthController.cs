using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Raqeeb.Application.DTOs;
using Raqeeb.Application.Interfaces;
using Raqeeb.Domain.Entities;
using BCrypt.Net;

namespace Raqeeb.API.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IUserRepository _users;
    public AuthController(IUserRepository users) => _users = users;

    /// <summary>POST /api/auth/register</summary>
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req)
    {
        if (await _users.GetByEmailAsync(req.Email) is not null)
            return Conflict(new { error = "Email already registered." });

        var user = new User
        {
            Email        = req.Email,
            PasswordHash = BCrypt.HashPassword(req.Password)
        };
        var created = await _users.CreateAsync(user);
        return Ok(new { id = created.Id, email = created.Email, createdAt = created.CreatedAt });
    }

    /// <summary>POST /api/auth/login</summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        var user = await _users.GetByEmailAsync(req.Email);
        if (user is null || !BCrypt.Verify(req.Password, user.PasswordHash))
            return Unauthorized(new { error = "Invalid email or password." });

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Email, user.Email)
        };
        var principal = new ClaimsPrincipal(
            new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

        return Ok(new { id = user.Id, email = user.Email, hasActiveSubscription = user.HasActiveSubscription });
    }

    /// <summary>GET /api/auth/me</summary>
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (idStr is null) return Unauthorized();
        var user = await _users.GetByIdAsync(Guid.Parse(idStr));
        if (user is null) return Unauthorized();
        return Ok(new { id = user.Id, email = user.Email, hasActiveSubscription = user.HasActiveSubscription, createdAt = user.CreatedAt });
    }

    /// <summary>POST /api/auth/logout</summary>
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Ok(new { message = "Logged out." });
    }
}
