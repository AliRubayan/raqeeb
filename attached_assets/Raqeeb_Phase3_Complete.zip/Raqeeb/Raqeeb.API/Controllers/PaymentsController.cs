using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Raqeeb.Application.DTOs;
using Raqeeb.Application.Interfaces;
using Raqeeb.Infrastructure.Services;

namespace Raqeeb.API.Controllers;

[ApiController]
[Route("api/payments")]
public class PaymentsController : ControllerBase
{
    private readonly IContractRepository _contracts;
    private readonly IUserRepository     _users;
    private readonly StreamPayService    _streamPay;

    public PaymentsController(IContractRepository contracts, IUserRepository users, StreamPayService streamPay)
    {
        _contracts = contracts;
        _users     = users;
        _streamPay = streamPay;
    }

    private Guid UserId =>
        Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>POST /api/payments/create-link — get real StreamPay checkout URL (299 SAR)</summary>
    [HttpPost("create-link")]
    [Authorize]
    public async Task<IActionResult> CreateLink([FromBody] CreatePaymentLinkRequest req)
    {
        var contract = await _contracts.GetByIdAsync(req.ContractId);
        if (contract is null || contract.UserId != UserId) return NotFound();

        var baseUrl = $"{Request.Scheme}://{Request.Host}";
        var url = await _streamPay.CreatePaymentLinkAsync(
            req.ContractId,
            contract.ContractName,
            $"{baseUrl}/payment/success?contractId={req.ContractId}",
            $"{baseUrl}/payment/failure?contractId={req.ContractId}");

        await _contracts.UpdatePaymentLinkAsync(req.ContractId, req.ContractId.ToString());
        return Ok(new { paymentUrl = url, contractId = req.ContractId });
    }

    /// <summary>POST /api/payments/callback — StreamPay posts here after payment</summary>
    [HttpPost("callback")]
    [AllowAnonymous]
    public async Task<IActionResult> Callback([FromBody] StreamPayCallbackRequest req)
    {
        if (req.PaymentStatus is "confirmed" or "paid")
        {
            var contract = await _contracts.GetByIdAsync(req.ContractId);
            if (contract is not null)
            {
                await _users.UpdateSubscriptionAsync(contract.UserId, true);
                await _contracts.UpdateStatusAsync(req.ContractId, Domain.Entities.ContractStatus.Paid);
            }
        }
        return Ok(new { received = true });
    }

    /// <summary>GET /api/payments/verify/{paymentLinkId}</summary>
    [HttpGet("verify/{paymentLinkId}")]
    [Authorize]
    public async Task<IActionResult> Verify(string paymentLinkId)
    {
        var status = await _streamPay.GetPaymentStatusAsync(paymentLinkId);
        return Ok(new { paymentLinkId, status });
    }
}
