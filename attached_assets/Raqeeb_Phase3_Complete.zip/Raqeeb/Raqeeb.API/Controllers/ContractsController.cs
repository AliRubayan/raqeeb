using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Raqeeb.Application.DTOs;
using Raqeeb.Application.Interfaces;
using Raqeeb.Domain.Entities;

namespace Raqeeb.API.Controllers;

[ApiController]
[Route("api/contracts")]
[Authorize]
public class ContractsController : ControllerBase
{
    private readonly IContractRepository _contracts;
    private readonly IUserRepository     _users;

    public ContractsController(IContractRepository contracts, IUserRepository users)
    {
        _contracts = contracts;
        _users     = users;
    }

    private Guid UserId =>
        Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    /// <summary>POST /api/contracts — create a new contract</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateContractRequest req)
    {
        var contract = new Contract
        {
            UserId       = UserId,
            ContractName = req.ContractName,
            ContractText = req.ContractText,
            Status       = ContractStatus.Paid
        };
        var created = await _contracts.CreateAsync(contract);
        return Ok(new
        {
            id           = created.Id,
            contractName = created.ContractName,
            status       = created.Status.ToString(),
            createdAt    = created.CreatedAt
        });
    }

    /// <summary>GET /api/contracts/history — dashboard data</summary>
    [HttpGet("history")]
    public async Task<IActionResult> History()
    {
        var contracts = await _contracts.GetByUserIdAsync(UserId);
        return Ok(contracts.Select(c => new
        {
            id              = c.Id,
            contractName    = c.ContractName,
            status          = c.Status.ToString(),
            streamChannelId = c.StreamChannelId,
            createdAt       = c.CreatedAt,
            riskScore       = c.AuditResult?.RiskScore,
            severity        = c.AuditResult?.Severity.ToString()
        }));
    }

    /// <summary>GET /api/contracts/{id}</summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetById(Guid id)
    {
        var c = await _contracts.GetByIdAsync(id);
        if (c is null || c.UserId != UserId) return NotFound();
        return Ok(c);
    }
}
