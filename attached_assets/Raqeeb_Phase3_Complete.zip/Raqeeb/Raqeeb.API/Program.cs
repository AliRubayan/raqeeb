using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Raqeeb.Application.Interfaces;
using Raqeeb.Application.Services;
using Raqeeb.Infrastructure.Data;
using Raqeeb.Infrastructure.Repositories;
using Raqeeb.Infrastructure.Services;

var builder = WebApplication.CreateBuilder(args);

// ─────────────────────────────────────────────
// DATABASE — SQLite (dev) or SQL Server (prod)
// ─────────────────────────────────────────────
builder.Services.AddDbContext<RaqeebDbContext>(options =>
    options.UseSqlite(
        builder.Configuration.GetConnectionString("DefaultConnection")
        ?? "Data Source=raqeeb.db"));

// ─────────────────────────────────────────────
// AUTHENTICATION — cookie-based sessions
// ─────────────────────────────────────────────
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name     = "raqeeb_session";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.LoginPath       = "/login";
        options.ExpireTimeSpan  = TimeSpan.FromDays(7);
        // Return 401 for API routes instead of redirect
        options.Events.OnRedirectToLogin = ctx =>
        {
            ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
            return Task.CompletedTask;
        };
    });
builder.Services.AddAuthorization();

// ─────────────────────────────────────────────
// REPOSITORIES
// ─────────────────────────────────────────────
builder.Services.AddScoped<IUserRepository,        UserRepository>();
builder.Services.AddScoped<IContractRepository,    ContractRepository>();
builder.Services.AddScoped<IAuditResultRepository, AuditResultRepository>();

// ─────────────────────────────────────────────
// SERVICES
// ─────────────────────────────────────────────
builder.Services.AddScoped<AuditService>();
builder.Services.AddScoped<StreamPayService>();
builder.Services.AddScoped<StreamService>();

// ─────────────────────────────────────────────
// HTTP clients (for StreamPay + n8n calls)
// ─────────────────────────────────────────────
builder.Services.AddHttpClient();

// ─────────────────────────────────────────────
// CORS — allow local React/Vite frontend in dev
// ─────────────────────────────────────────────
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
    c.SwaggerDoc("v1", new() { Title = "Raqeeb API — رقيب", Version = "v1" }));

var app = builder.Build();

// ─────────────────────────────────────────────
// AUTO-MIGRATE ON STARTUP (creates DB + tables)
// ─────────────────────────────────────────────
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<RaqeebDbContext>();
    db.Database.EnsureCreated();
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Raqeeb API v1"));
}

app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapFallbackToFile("login.html");

app.Run();
