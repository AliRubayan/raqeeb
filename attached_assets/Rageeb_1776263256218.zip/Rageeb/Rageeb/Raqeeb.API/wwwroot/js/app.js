const RAQEEB_STORAGE_KEY = "raqeebAuditState";
const STREAM_BOOTSTRAP_ENDPOINT = "/api/stream/bootstrap";
const STREAMPAY_CREATE_SESSION_ENDPOINT = "/api/streampay/create-session";
const STREAMPAY_CALLBACK_ENDPOINT = "/api/streampay/callback";
const N8N_WEBHOOK_URL = "https://your-n8n-url/webhook/4b10f002-a438-481d-b968-ecf9039e71b5";

const defaultAuditState = {
  contractId: "",
  contractName: "",
  contractValue: "0",
  contractFileName: "",
  contractText: "",
  status: "pending",
  statusLabel: "Awaiting analysis",
  riskScore: 0,
  reducedRiskScore: 0,
  severity: "Unknown",
  violatedLaw: "",
  violationFound: false,
  inspector_result: "",
  law_result: "",
  drafter_result: "",
  createdAt: ""
};

function getAuditState() {
  const raw = localStorage.getItem(RAQEEB_STORAGE_KEY);
  if (!raw) return { ...defaultAuditState };
  try {
    return { ...defaultAuditState, ...JSON.parse(raw) };
  } catch {
    return { ...defaultAuditState };
  }
}

function setAuditState(nextState) {
  localStorage.setItem(RAQEEB_STORAGE_KEY, JSON.stringify(nextState));
}

function navigateTo(path) {
  window.location.href = path;
}

function generateContractId() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }
  return `contract-${Date.now()}`;
}

async function safeFetchJson(url, options) {
  try {
    const response = await fetch(url, options);
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}

function wireLoginPage() {
  const loginBtn = document.getElementById("loginBtn");
  if (!loginBtn) return;
  loginBtn.addEventListener("click", () => navigateTo("dashboard.html"));
}

function wireDashboardPage() {
  const newAuditBtn = document.getElementById("newAuditBtn");
  if (newAuditBtn) {
    newAuditBtn.addEventListener("click", () => navigateTo("payment-gate.html"));
  }

  const globalFeed = document.getElementById("globalActivityFeed");
  if (!globalFeed) return;

  safeFetchJson(STREAM_BOOTSTRAP_ENDPOINT).then((payload) => {
    const events = payload?.activity_feed;
    if (!Array.isArray(events) || events.length === 0) return;

    globalFeed.innerHTML = "";
    events.forEach((event) => {
      const item = document.createElement("li");
      item.className = "rounded-xl bg-white/5 p-3";
      item.textContent = event;
      globalFeed.appendChild(item);
    });
  });
}

function wirePaymentGatePage() {
  const paymentStatus = document.getElementById("paymentStatus");
  if (!paymentStatus) return;

  const currentState = getAuditState();
  const checkpoints = [
    "Creating StreamPay audit session...",
    "Authorizing enterprise payment token...",
    "Waiting for StreamPay callback confirmation..."
  ];

  const runPaymentFlow = async () => {
    const session = await safeFetchJson(STREAMPAY_CREATE_SESSION_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contractName: currentState.contractName,
        contractValue: Number(currentState.contractValue || 0)
      })
    });

    if (!session) {
      paymentStatus.textContent = "StreamPay session failed. Retrying...";
      setTimeout(runPaymentFlow, 1000);
      return;
    }

    let index = 0;
    const interval = setInterval(async () => {
      paymentStatus.textContent = checkpoints[index];
      index += 1;

      if (index === checkpoints.length) {
        clearInterval(interval);
        const callback = await safeFetchJson(`${STREAMPAY_CALLBACK_ENDPOINT}?sessionId=${session.session_id}`);
        if (callback?.payment_status === "confirmed") {
          paymentStatus.textContent = "Payment confirmed. Audit slot secured.";
          setTimeout(() => navigateTo("contract-upload.html"), 1100);
          return;
        }

        paymentStatus.textContent = "Awaiting StreamPay confirmation...";
      }
    }, 1400);
  };

  runPaymentFlow();
}

function wireUploadPage() {
  const form = document.getElementById("uploadForm");
  if (!form) return;

  const contractIdInput = document.getElementById("contractId");
  if (contractIdInput && !contractIdInput.value) {
    contractIdInput.value = generateContractId();
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const contractId = document.getElementById("contractId").value || generateContractId();
    const contractName = document.getElementById("contractName").value || "Untitled Contract";
    const contractValue = document.getElementById("contractValue").value || "0";
    const contractText = document.getElementById("contractText").value || "";
    const contractFile = document.getElementById("contractFile")?.files?.[0];

    if (!contractText && !contractFile) {
      alert("Please upload a PDF file or paste contract text.");
      return;
    }

    const normalizedText = contractText || `[PDF Uploaded] ${contractFile.name}`;

    const nextState = {
      ...getAuditState(),
      contractId,
      contractName,
      contractValue,
      contractFileName: contractFile?.name || "",
      contractText: normalizedText,
      createdAt: new Date().toISOString(),
      status: "processing",
      statusLabel: "Sent to Inspector",
      sourcePreview: normalizedText.slice(0, 120)
    };
    setAuditState(nextState);

    const n8nPayload = {
      contract_text: normalizedText,
      contract_id: contractId,
      contract_value: contractValue
    };

    const result = await safeFetchJson(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(n8nPayload)
    });

    if (result) {
      const mergedState = {
        ...nextState,
        contractId: result.contract_id ?? contractId,
        status: result.status ?? "done",
        statusLabel: result.status_label ?? "Report ready",
        riskScore: Number(result.risk_score ?? 0),
        severity: result.severity ?? "Unknown",
        violatedLaw: result.violated_law ?? "",
        violationFound: Boolean(result.violation_found),
        inspector_result: result.inspector ?? "Inspector result not provided.",
        law_result: result.lawfinder ?? "Law finder result not provided.",
        drafter_result: result.drafter ?? "Drafter result not provided."
      };

      // Derive reduced score for final report visualization.
      mergedState.reducedRiskScore = Math.max(0, mergedState.riskScore - 61);
      setAuditState(mergedState);
    }

    navigateTo("live-analysis.html");
  });
}

function wireLiveAnalysisPage() {
  const timeline = document.getElementById("timelineList");
  if (!timeline) return;
  const state = getAuditState();

  const events = [
    "Contract Received.",
    "Inspector reading...",
    "Oracle checking SAMA Article 4...",
    "Lawyer drafting amendment...",
    state.statusLabel || "Report Ready."
  ];

  let counter = 0;
  const seed = new Date();
  const appendEvent = () => {
    const item = document.createElement("li");
    const time = new Date(seed.getTime() + counter * 6000)
      .toTimeString()
      .split(" ")[0];
    item.className = "rounded-xl border border-[#D4AF37]/30 bg-slate-900/60 p-4";
    item.innerHTML = `<span class="text-[#D4AF37] font-semibold">${time}</span> - ${events[counter]}`;
    timeline.appendChild(item);

    if (counter === events.length - 1) {
      setTimeout(() => navigateTo("decision-room.html"), 1400);
      return;
    }

    counter += 1;
    setTimeout(appendEvent, 1400);
  };

  appendEvent();
}

async function renderDecisionData() {
  const state = getAuditState();
  const name = document.getElementById("decisionContractName");
  const risk = document.getElementById("decisionRisk");
  const value = document.getElementById("decisionValue");
  const contractMeta = document.getElementById("decisionContractMeta");
  const chat = document.getElementById("decisionChat");
  if (!name || !risk || !value || !chat) return;

  name.textContent = state.contractName;
  risk.textContent = `${state.riskScore}% (${state.severity})`;
  value.textContent = `${Number(state.contractValue).toLocaleString("en-US")} SAR`;
  if (contractMeta) {
    contractMeta.textContent = `ID: ${state.contractId || "-"}${state.contractFileName ? ` | File: ${state.contractFileName}` : ""}`;
  }

  const streamBootstrap = await safeFetchJson(STREAM_BOOTSTRAP_ENDPOINT);
  const messages = streamBootstrap?.decision_room ?? [
    { agent: "Inspector", text: state.inspector_result },
    { agent: "Oracle", text: state.law_result },
    { agent: "Lawyer", text: state.drafter_result }
  ];

  chat.innerHTML = "";
  messages.forEach((msg) => {
    const bubble = document.createElement("div");
    bubble.className = "rounded-xl bg-slate-900/70 border border-[#D4AF37]/20 p-4";
    bubble.innerHTML = `<p class="text-[#D4AF37] font-semibold">${msg.agent}</p><p class="text-slate-100 mt-1">${msg.text}</p>`;
    chat.appendChild(bubble);
  });
}

function wireDecisionPage() {
  renderDecisionData();

  const approve = document.getElementById("approveBtn");
  const reject = document.getElementById("rejectBtn");
  const review = document.getElementById("reviewBtn");

  if (approve) approve.addEventListener("click", () => navigateTo("final-report.html"));
  if (reject) reject.addEventListener("click", () => navigateTo("dashboard.html"));
  if (review) review.addEventListener("click", () => navigateTo("live-analysis.html"));
}

function wireReportPage() {
  const state = getAuditState();
  const contractName = document.getElementById("reportContractName");
  const riskDelta = document.getElementById("riskDelta");
  const reportValue = document.getElementById("reportValue");
  const reportMeta = document.getElementById("reportMeta");
  const download = document.getElementById("downloadReportBtn");
  const back = document.getElementById("backToDashboardBtn");

  if (contractName) contractName.textContent = state.contractName;
  if (riskDelta) riskDelta.textContent = `${state.riskScore}% → ${state.reducedRiskScore}%`;
  if (reportValue) reportValue.textContent = `${Number(state.contractValue).toLocaleString("en-US")} SAR`;
  if (reportMeta) {
    reportMeta.textContent = `ID: ${state.contractId || "-"} | ${state.violatedLaw || "No law mapping provided"}`;
  }

  if (download) {
    download.addEventListener("click", () => {
      const payload = `Raqeeb Final Report
Contract: ${state.contractName}
Contract ID: ${state.contractId}
Value: ${state.contractValue} SAR
Risk: ${state.riskScore}% -> ${state.reducedRiskScore}%
Severity: ${state.severity}
Violated Law: ${state.violatedLaw}
Inspector: ${state.inspector_result}
Law Finder: ${state.law_result}
Drafter: ${state.drafter_result}
Created At: ${state.createdAt}
`;
      const blob = new Blob([payload], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "raqeeb-audit-report.txt";
      link.click();
      URL.revokeObjectURL(url);
    });
  }

  if (back) back.addEventListener("click", () => navigateTo("dashboard.html"));
}

function wireSettingsPage() {
  const dashboardBtn = document.getElementById("goDashboardBtn");
  if (dashboardBtn) dashboardBtn.addEventListener("click", () => navigateTo("dashboard.html"));
}

function initPage() {
  wireLoginPage();
  wireDashboardPage();
  wirePaymentGatePage();
  wireUploadPage();
  wireLiveAnalysisPage();
  wireDecisionPage();
  wireReportPage();
  wireSettingsPage();
}

document.addEventListener("DOMContentLoaded", initPage);
