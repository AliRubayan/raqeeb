using Microsoft.AspNetCore.Mvc;

namespace Raqeeb.API.Controllers;

[ApiController]
[Route("api")]
public class IntegrationsController : ControllerBase
{
    [HttpPost("streampay/create-session")]
    public IActionResult CreateStreamPaySession([FromBody] StreamPaySessionRequest request)
    {
        var sessionId = $"sp_{Guid.NewGuid():N}";
        return Ok(new
        {
            provider = "StreamPay",
            status = "pending",
            session_id = sessionId,
            amount_sar = request.ContractValue,
            checkout_url = $"https://docs.streampay.sa/checkout/{sessionId}",
            callback_url = $"/api/streampay/callback?sessionId={sessionId}"
        });
    }

    [HttpGet("streampay/callback")]
    public IActionResult StreamPayCallback([FromQuery] string sessionId)
    {
        return Ok(new
        {
            provider = "StreamPay",
            session_id = sessionId,
            payment_status = "confirmed"
        });
    }

    [HttpGet("stream/bootstrap")]
    public IActionResult StreamBootstrap()
    {
        return Ok(new
        {
            provider = "getstream.io",
            activity_feed = new[]
            {
                "Inspector published risk scan to activity feed.",
                "Oracle mapped findings to PDPL and SAMA references.",
                "Lawyer posted bilingual amendment draft to decision room."
            },
            decision_room = new[]
            {
                new { agent = "Inspector", text = "Potential over-collection of personal data detected." },
                new { agent = "Oracle", text = "PDPL obligations and SAMA control references attached." },
                new { agent = "Lawyer", text = "Arabic and English amendment draft is ready for approval." }
            }
        });
    }
}

public record StreamPaySessionRequest(string ContractName, decimal ContractValue);
