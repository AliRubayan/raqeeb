﻿namespace Raqeeb.API.Controllers
{
    public class ComplianceController
    {
    }
}
